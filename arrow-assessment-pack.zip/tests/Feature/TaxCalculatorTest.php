<?php

namespace Tests\Feature;

use Tests\TestCase;

class TaxCalculatorTest extends TestCase
{
    private function headerParams() {
        return [
            "Accept" => "application/json",
            "Content-Type" => "application/json",
        ];
    }

    private function responseStructureAssertion() {
        return [
            'products' => [
                '*' => [
                    'name',
                    'price',
                    'quantity',
                    'tax',
                    'total',
                ]
            ],
            'shipping',
            'sub_total',
            'tax_total',
            'total',
        ];
    }

    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function test_calculate_total_with_tax_and_shipping()
    {
        $payload = [
            'products' => [
                [
                    'name' => 'Product 1',
                    'price' => '10.00',
                    'quantity' => 5,
                ],
                [
                    'name' => 'Product 2',
                    'price' => '39.9',
                    'quantity' => 2,
                ],
                [
                    'name' => 'Product 3',
                    'price' => '89.00',
                    'quantity' => 1,
                ],
            ],
            'shipping' => '10.00',
            'tax' => [
                'rate' => '10.00', // rate in percentage
                'shipping_incl' => true,
            ]
        ];

        $response = $this->withHeaders($this->headerParams())
            ->postJson('/api/cart/total',$payload)
            ->assertJsonStructure($this->responseStructureAssertion())
            // Check against expected value with the api response
            ->assertJson([
                'sub_total' => '218.80',
                'tax_total' => '21.88',
                'shipping' => '10.00',
                'total' => '250.68',
            ], false);

        $response->assertStatus(200);
    }

    public function test_calculate_total_without_tax_and_with_shipping()
    {
        $payload = [
            'products' => [
                [
                    'name' => 'Product 1',
                    'price' => '10.00',
                    'quantity' => 5,
                ],
                [
                    'name' => 'Product 2',
                    'price' => '39.9',
                    'quantity' => 2,
                ],
                [
                    'name' => 'Product 3',
                    'price' => '89.00',
                    'quantity' => 1,
                ],
            ],
            'shipping' => '10.00',
            'tax' => [
                'rate' => '10.00', // rate in percentage
                'shipping_incl' => false,
            ]
        ];

        $response = $this->withHeaders($this->headerParams())
            ->postJson('/api/cart/total',$payload)
            ->assertJsonStructure($this->responseStructureAssertion())
            // Check against expected value with the api response
            ->assertJson([
                'sub_total' => '218.80',
                'tax_total' => '0.00',
                'shipping' => '10.00',
                'total' => '228.80',
            ], false);

        $response->assertStatus(200);
    }

    public function test_calculate_total_without_tax_and_shipping()
    {
        $payload = [
            'products' => [
                [
                    'name' => 'Product 1',
                    'price' => '10.00',
                    'quantity' => 5,
                ],
                [
                    'name' => 'Product 2',
                    'price' => '39.9',
                    'quantity' => 2,
                ],
                [
                    'name' => 'Product 3',
                    'price' => '89.00',
                    'quantity' => 1,
                ],
            ],
            'shipping' => '0.00',
            'tax' => [
                'rate' => '10.00', // rate in percentage
                'shipping_incl' => false,
            ]
        ];

        $response = $this->withHeaders($this->headerParams())
            ->postJson('/api/cart/total',$payload)
            ->assertJsonStructure($this->responseStructureAssertion())
            // Check against expected value with the api response
            ->assertJson([
                'sub_total' => '218.80',
                'tax_total' => '0.00',
                'shipping' => '0.00',
                'total' => '218.80',
            ], false);

        $response->assertStatus(200);
    }

    public function test_calculate_total_with_invalid_tax_params()
    {
        $payload = [
            'products' => [
                [
                    'name' => 'Product 1',
                    'price' => '10.00',
                    'quantity' => 5,
                ],
                [
                    'name' => 'Product 3',
                    'price' => '89.00',
                    'quantity' => 1,
                ],
            ],
            'shipping' => '0.00',
        ];

        $response = $this->withHeaders($this->headerParams())
            ->postJson('/api/cart/total',$payload)
            ->assertJsonStructure($this->responseStructureAssertion())
            // Check against expected value with the api response
            ->assertJson([
                'sub_total' => '139.00',
                'tax_total' => '0.00',
                'shipping' => '0.00',
                'total' => '139.00',
            ], false);

        $response->assertStatus(200);
    }
}
