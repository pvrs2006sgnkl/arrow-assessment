<?php

namespace App\Http\Controllers\V1\Cart;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Cart\CalculateTotalRequest;
use App\Service\CartService;
use Illuminate\Http\Request;

class CalculatorController extends Controller
{
    public function __construct(CartService $cartService)
    {
        $this->cartService = $cartService;
    }

    public function calculate(CalculateTotalRequest $request) {
        return $result = $this->cartService->calculateTotal($request);
        dd($result);
    }
}
