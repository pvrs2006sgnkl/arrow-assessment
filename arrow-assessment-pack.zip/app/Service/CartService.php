<?php

namespace App\Service;

class CartService
{
    public function calculateTotal($request) {

        $shipping_amt = ($request->shipping <= 0)? 0 : $request->shipping;
        $tax = $request->tax;

        $this->sub_total_amt = $this->total_tax_amt = $this->total_amt = 0.00;

        return collect($request->products)->mapToGroups(function($product) use($shipping_amt, $tax) {
            $product = collect($product);
            $tax = collect($tax);

            $item_sub_total = number_format(($product->get('price') * $product->get('quantity')), 2);

            $tax = ($tax->get('shipping_incl') && $tax->get('rate') > 0)? ($item_sub_total * ($tax->get('rate')/100)) : 0;
            $tax = number_format($tax, 2);

            $this->sub_total_amt += $item_sub_total;
            $this->total_tax_amt += $tax;

            $this->total_amt += ($item_sub_total+$tax);

            return [
               'products' => collect($product)->merge([
                    'tax' => $tax,
                    'total' => number_format($item_sub_total+$tax, 2),
                ])];
        })->merge([
            'sub_total' => number_format($this->sub_total_amt, 2),
            'tax_total' => number_format($this->total_tax_amt, 2),
            'shipping' => number_format($shipping_amt, 2),
            'total' => number_format(($this->total_amt+$shipping_amt), 2),
        ]);
    }
}
